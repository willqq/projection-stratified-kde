# Preregistered upgrade protocol

Recorded 2026-09-20 before any new algorithm measurements. The goal began at approximately 15:43 China Standard Time. Stop exploration by 2026-09-21 15:43 (24 hours); the final 90 minutes are reserved for verification and delivery. An authentication delay does not justify extending the search or inventing results.

## Frozen baseline

The verified source/PDF and corresponding structural, enhancement and mechanism records are copied in full to `baseline_backup/`, with a SHA-256 manifest. The source that produced the inspected final PDF is `final_verification_20260920/manuscript/ICASSP2027_EN_revised_final.tex`. The requested filename suffix `(2)` has not been located; identity follows the verified source, PDF hash and evidence, not an assumed filename match. No baseline file will be edited.

The method remains Gaussian projection r=64, seed 20260916, J=8, exact projected-score subset floor(M/4), equal-population remainder, residual-capacity proportional allocation and original-space kernels. Frozen references, train-fitted preprocessing, bandwidth, query IDs and budgets are unchanged. All previous test and audit queries are exposed. No fresh-test claim will be made.

## Path A: equivalent partition construction

Question: does removing unnecessary within-cell sorting materially reduce complete query time?

Hypothesis: multirank selection can recover exactly the same H and cell member sets as lexicographic (score, identifier) sorting, with lower construction cost.

Change: partition implementation only. Use exact order-statistic boundaries. If ties cross a cut, a deterministic exact fallback must preserve the identifier tie rule. No approximate quantiles or changed scores.

Correctness gates: compare every H and cell member set, population and allocation; check coverage/disjointness; include all-equal scores, repeated boundary values, shuffled IDs, small populations and every frozen budget. Validate estimates with identifier-coupled sampling outside timing. Internal permutations may change a seeded positional draw, but not its uniform without-replacement law. Tests of distribution must use the original estimator and exact analytical variance on small synthetic populations. Real validation queries receive the same membership checks.

Profiling separates projection, low-dimensional scan, sorting/selection, ID gathering, cell slicing, sampling, original-space kernel evaluation and aggregation. The previous combined 78% number is not evidence of sorting alone. Instrumented breakdowns and complete-query production timing will be distinguished.

Feasibility gate: no correctness failures and at least 20% lower median complete-query time for two adjacent budgets in one prespecified dataset/scale. Check all four original reference sets plus the existing real GIST n=20,000 reference set. This threshold controls project effort, not publication eligibility.

## Path B: transfer to a strong ANN-selected H

Question: does projected remainder stratification add value after the ANN retrieval used by well-tuned DEANN?

Compare controlled ANN-H + uniform remainder with controlled ANN-H + eight projected-score remainder strata. Use precisely the same valid unique H IDs, actual H size, complement, h, total kernel count and without-replacement sampling convention. Both use the same proportional residual-capacity allocation rule. Keep official DEANN as a separately named implementation; the controlled Single estimator is not official DEANN.

Use the two already validation-frozen DEANN anchors (error-selected E and latency-selected T). Their nprobe and H/M fractions are immutable during this study. No additional ANN grid. Deduplicate returned IDs, account for absent neighbors and assert H/complement disjointness and full coverage. Reuse any original-space distances already computed by the ANN precision wrapper when evaluating H, while charging their actual cost and distance counts. No query truth is passed to online code.

Validation feasibility uses all 80 frozen validation queries on four datasets, M=64/128/256 and sampling seeds 0..4. Calculate conditional variance anew under each ANN-H. Do not reuse the projected-H 0.55--0.66 values. Each anchor is a full curve, not a per-test-point choice.

Feasibility gate: at least one dataset has >=10% relative mean-error reduction at two adjacent budgets, positive paired query-bootstrap lower bounds, and median conditional variance ratio <=0.90 at those settings. Report all anchors/datasets including failures. If neither anchor meets this gate, stop Path B before formal evaluation. Statistical feasibility alone does not authorize a computational claim.

## Timing and formal evaluation

Use the existing Xeon Gold 6459C server, eight CPU/BLAS threads, original float32 stored features and float64 computation conventions. No training or other task-owned benchmark runs concurrently. Log hardware, package versions, CPU load, code hashes, commit and uncommitted diff. Use three warmed repetitions and deterministic randomized interleaving of methods within each query/repetition. Preserve all timings and report medians. If external load is substantial, report it and defer that timing block rather than silently discarding results.

Formal evaluation, only for paths meeting their feasibility gate: all four existing test sets (200 queries each), existing same-source audits where available (200 each), M=32/64/128/256/512, sampling seeds 0..4. Retain Uniform, Exact sum, current Projected strata, and official DEANN original/E/T frozen curves. Report duplicate configurations only once with aliases recorded. Keep exact annular as the fixed statistical reference. For A's scale gate, reuse the existing nested GIST reference sets and 100 previously used audit queries at M=64/128/256; identify this smaller grid explicitly.

Paired inference resamples queries (1000 resamples, seed 20260920), after averaging sampling seeds within query. Report pointwise 95% intervals and their unadjusted status. Keep nominal M, unique sampled IDs, actual kernel calls, original-space distance/dot counts, low-dimensional score counts and ANN visits separate. All online phases count toward latency.

## End-to-end comparisons

Prespecified relative-error targets: 5%, 10%, 15%, 20%. For each method and dataset, choose the fastest measured budget point that actually meets each target; otherwise report `unattained`. Do not interpolate or extrapolate. Evaluate error under complete-query time caps 0.125, 0.25, 0.5, 1, 2 and 4 ms, choosing the lowest-error measured eligible point and reporting unattained caps. All frozen official DEANN curves are eligible. These are descriptive measured envelopes; query-level uncertainty is reported separately.

## Merge rules

A: merge an equivalent implementation only if formal measurements confirm >=20% complete-query median reduction over current Projected strata at two adjacent budgets in a prespecified dataset/scale, with no correctness change. Report regressions elsewhere. Local-function speed alone fails.

B: a method enhancement requires formal confirmation of the ANN-H statistical increment plus end-to-end value: >=10% lower error at two adjacent prespecified time caps, or >=10% lower latency at two adjacent error targets, in at least one dataset relative to the best eligible existing method. Preserve other datasets and negative outcomes. Do not select a weaker DEANN anchor to make this pass.

C: both conditions hold; integrate only the supported increment.

D: neither holds; retain the frozen submission candidate and deliver the negative results. Correct any discovered technical error regardless of merge outcome. No third route or iterative rescue study.

Deliver UPGRADE_FEASIBILITY.md, UPGRADE_RESULTS.md and MERGE_DECISION.md with reproducible code, raw rows and provenance. Until required results exist, mark those conclusions pending rather than passing them.
