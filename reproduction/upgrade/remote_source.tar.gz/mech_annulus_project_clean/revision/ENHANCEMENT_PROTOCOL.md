# ICASSP 最终实验增强：预先决策与协议

状态：PREDECLARED；2026-09-20，北京时间。本文写入后才运行新增评测。主稿保持不动。

## 基线与版本

当前可定位的最新交付为 `../structural_revision_20260919/manuscript/ICASSP2027_EN_revised_final.pdf`，SHA256 `6e5a69f26c5a32c439f4b4d981fb7b248739299bd092f8caa9b832f948276d37`。本机索引及 Downloads 尚未找到字面名称带 `(1)` 的文件，已向作者询问。本轮先以该最新交付及配套源码开展评估；若作者指出内容不同的文件，先核对差异，不能悄悄替换基线。

科学实现为 59d86db；上轮增加种子检查后为 6741795。远程旧目录保持原状，新增代码及输出使用独立 worktree。`baseline/MANIFEST.json` 冻结论文、现有分析、逐查询结果及实现的哈希。三种投影种子检查属于既有证据。

## Reviewer-gap audit

| Claim | 已有证据 | 本轮判断 |
|---|---|---|
| Exact annuli 有统计价值 | 20 个 test dataset–budget 点较 MC 降误差 51.5–71.9% | 当前 h/n 下支持充分，不重复开发或优化 |
| Projected grouping 优于随机分组 | C=P、H 为空、人数与分配匹配；M128 方差比 0.596–0.739，随机约 1 | 当前 h/n 下支持充分；不能等同最终带 H 的误差收益 |
| 固定 H 后多层仍有增量 | 四 test 降误差 17.7–24.5%；三个同源 audit 21.7–22.3%，CI 排除零 | 核心贡献的直接证据；需检查 bandwidth 外推 |
| 结果不依赖一个 projection seed | 3 seeds × 7 query sets × 3 budgets，63/63 CI 下界为正 | 有限种子范围已支持；不再重复 |
| 结果有 audit 支持 | 三个同矩阵原未用查询集，各 200；Amazon 无可用行 | 降低研究过程适配疑虑；这些 audit 现在已被查看，不再称新的未见评测 |
| 完整时延有收益 | Amazon 三个预算、CIFAR 一个端点；其余点被支配 | 证据支持窄范围；需要更强 DEANN 和较大 n 检查 |
| DEANN 比较公平 | 官方实现及精度修正核验；仅 20 validation queries、四对参数、M128 | 实现可信，调优覆盖仍不足 |

最危险的三个缺口：

1. **Bandwidth：High。** 核函数集中程度直接影响分层收益。固定 H 的带宽检查可以改变机制适用范围判断，值得占用少量正文空间。
2. **Reference size：High。** 当前 n=720/1800 无法检验全量低维扫描及排序的增长。扩大同一原始数据的 n 能实质改变计算适用范围判断。
3. **DEANN 调优：High。** 当前少数 frontier 点对对手调优很敏感。公平压力测试可能要求收窄结论，应优先于新的展示性消融。

## 候选实验取舍

| 候选 | 信息增益 | 成本 | 推断风险 | 决定 |
|---|---|---|---|---|
| Bandwidth matched-H | 高；检验核心机制 | 低，固定 M128 | 小 h 相对误差尾部重；使用 log 真值与 query bootstrap | 执行 E1 |
| Recall vs variance 跨机制相关性 | 对一般预测性命题可能有价值 | 现有数据重分析低，公平新设计较高 | 全覆盖 recall 恒为 1；候选方法含偏差；跨 query 难度和配置变化混杂；解析方差与 MSE 的关系部分由恒等式决定 | 不新增实验；审计已有对照，报告识别边界 |
| GIST reference scaling | 高；直测 n 依赖 | 中，最多 20k、100 固定查询 | 单一数据集和同源 query 限制外推 | 执行 E2 |
| DEANN validation-only stress | 高；检验 frontier 稳定性 | 中，有限网格 | 不应在 test 上挑一个赢家；需冻结整套曲线 | 执行 E3 |
| Projection dimension | 中低；解释 r64 但非当前最大缺口 | 中 | 易增加选择自由度 | 不执行 |

Top-3 为 E1、E2、E3。执行顺序 E1 → E3 validation 冻结 → E3 正式评测 → E2。仅 E3/E2 的 DEANN 使用声明的 validation 选择；投影方法全部固定。

## E1 — Bandwidth mechanism robustness

- Research question：改变 h 后，相同 H 和 M 的 Multi 是否仍优于 Single？
- Reviewer concern：目前增量是否只在一个 h 成立。
- Hypothesis：大部分数据与 bandwidth 组合保持正向 matched-H 效果；不假设每个组合都达到 20%。
- Fixed variables：原四 reference sets、预处理、全部四 test 与三 audit（每套 200）、r64/seed20260916、J8、H=M/4、比例分配、R0、M128、抽样 seeds0–4。
- Changed variable：h/h0 = 0.5, 0.75, 1, 1.5, 2，全部保留。
- Primary metric：Single 与 Multi 的 mean relative error 及相对下降；每套查询内部先平均五 seeds，1000 次 query-bootstrap，seed20260920，95% percentile CI。
- Secondary：同 H 的解析条件方差 Multi/Single 中位比；MC 和固定 R0 exact annular 的误差与 Recovery。若 MC−ExactAnnular <=0 或 query-bootstrap 区间含零，Recovery 标为不稳定而不截断；仍保留原始比值。
- Success condition：按四个 test 数据集 × 五倍率统计，超过半数组合 CI 下界>0，matched-H gain 中位数>10%；audit 单独列出，不充作额外独立数据集。该标准仅用于解释，无调参。
- Possible negative result：窄核中收益弱/负、区间含零，或宽核下增益随总体误差变小；如实限定机制。
- Would the result change the paper? **Yes**，一条带边界的 bandwidth 证据可替换原“untested”限制。
- 不比较新增单次计时与旧正式时延；本实验为统计机制检查。在线函数重新计算所选 original-space kernels，不读取离线真值。

## E2 — GIST reference-size scaling

- Research question：固定投影方法的统计回收与完整代价如何随 n 改变？
- Reviewer concern：只在小 reference set 有效。
- Hypothesis：统计收益可能保留；计算收益允许随扫描和排序增长而消失。
- Fixed variables：已有 GIST-512 原矩阵；原 train-fitted preprocessing；h0、R0；r64/seed20260916/J8/k=M/4/比例分配；固定原 audit 清单前 100 个 query（按现有顺序，不按误差筛选）；M64/128/256，seeds0–4。
- Changed variable：n=1000,1800,5000,10000,20000。原 reference 顺序前缀提供 1000/1800；超过 1800 从未属于 train/reference/validation/test/audit 的原始行中按 seed20260920 随机排列后追加。不复制行；所有 n 形成嵌套总体。先写完整 row-ID 清单和哈希。
- Comparators：MC、Exact annular、Projected strata、Exact summation，以及按下述共同规则只在原 80 validation queries 选择的 DEANN 曲线。n 改变目标参考总体，h 与预处理保持不变。
- Primary metric：Recovery 和各方法 mean relative error；完整查询 median ms，三次 warmed 调用，按 query 聚类统计。
- Breakdown：query projection、低维全 scan、sorting+strata、original-space kernel、其他；记录逐次计时并用逐次加和核验 total。纯排序与分层现有实现共用计时，明确合并，不伪称分开测得。预计算与存储单独记录。
- Success condition：多数 n×M 的稳定 Recovery>0.5；计算上展示相对 exact 与 DEANN 的真实曲线，不预设 crossover。
- Possible negative result：统计回收随 n 衰减，或排序/scan 使完整查询失去竞争力。保留所有 n，不调整方法。
- Would the result change the paper? **Yes**，回答稿件明确未验证的 n 限制；仅支持 GIST 的当前区间。

## E3 — DEANN fairness stress test

- Research question：更充分且事先冻结的 baseline tuning 是否改变计算结论？
- Reviewer concern：原四参数组合是否低估 DEANN。
- Hypothesis：DEANN 的 error–latency envelope 可能改善；matched-H 统计增量不依赖这个对手。
- Fixed variables：官方 AnnEstimatorPermuted、原空间 Gaussian 核与精度修正、现有 splits/h；原投影方法不调参。IVF nlist=min(32,floor(n/40)) 保留，避免升级为新的索引工程。
- Changed variable：nprobe=去重的 {1,2,4,8,16,nlist}；near fraction={0.125,0.25,0.5,0.75}；使用全部 80 validation queries、M64/128/256、sampling seeds0/1，三次调用、首个估计用于误差。每个实例先用 validation[0] warm up 一次。
- Selection：每个 dataset（scaling 为每个 n）只选三条完整配置曲线：平均 validation MARE 最低、median complete latency 最低、两者乘积最低；去重。各配置的指标在上述所有 validation budgets/seeds/queries 上聚合。确定性 tie-break 为更低 latency、nprobe、fraction。每一条配置用于全部正式预算，绝不按 test 点换参数。
- Freeze：四个原 dataset 的 grid 完成后写 selection.json 与哈希，然后才读 test/audit 做新增 DEANN 评测。scaling 每个 n 同样先 validation 冻结。保留原 DEANN 配置作为配对运行对照，即使它没有入选。
- Formal protocol：原四 test、三 audit 的全部 200 queries；五 budgets32/64/128/256/512；seeds0–4；warmup 一次、三次调用，首个估计及 median latency。新选 DEANN 各条曲线全部报告；同一时段重新计时 MC、Exact annular、Projected strata、Exact sum 与旧 DEANN，不用不同时段的时延拼新 frontier。
- Primary metric：包含全部 budgets 和 Exact sum 的 nondominated set；DEANN 的实际核调用、IVF 全维距离与 overlap correction 如实记录。对同一配置作 query-bootstrap CI；不将某个 query 上最优配置拼为虚构算法。
- Success condition：公平比较可完成；保持或失去 frontier 均是有价值答案，无保胜目标。
- Possible negative result：Amazon/CIFAR 的原 frontier 被新 baseline 支配，此时推荐 CLAIM NARROWING 或必要证据更新，不能继续沿用旧 frontier claim。
- Would the result change the paper? **Yes**，直接影响已写出的计算证据。

## 现有机制证据重审的边界

固定同一个 C 后，重分组并不改变 recall，因此单靠 recall 无法识别方差改善。Table2A 已经提供 C=P 下 projected/random/ordered 的控制；旧 validation 日志提供同 C 下 Hamming/real/random/ordered 的控制。可直接报告这些对应关系，不需新调参。Amazon 的旧分组可能已有较低方差但覆盖较差，必须一并呈现。

本轮不把 across-query 的 Spearman 大小写成一般预测结论：相对误差还受核集中程度、有限抽样噪声和候选偏差影响。条件 MSE=variance+bias² 已解释这一问题；以同一批精确核值计算两边再报告强相关会夸大信息增量。因此保留“recall alone cannot determine stratification quality”的有限论点；不升级为“recall generally weak, variance always stronger”。

## 结果后的论文决策

有可复现且不改变原计算结论的关键证据：B，MINOR EVIDENCE UPDATE；只建议替换少量文字/补充材料，不自动改稿。

新增结果暴露实质边界或更强 DEANN 改变原 frontier：C，CLAIM NARROWING；列出需要修改的具体句子，主稿仍保持冻结。

结果信息增益不足：A，KEEP CURRENT PAPER。所有原始结果照常交付。
