# Validation-only configuration selection record (2026-09-15 final round)

All selection used the 80 validation queries x budgets {64,128,256} x seeds {0..4}.
No test query participated in any selection, calibration fit, or early-stopping decision.

## Diagnosis that motivated the search (results/diag_v1, validation queries)
- T(r)=max(2,ceil(c*Theta/pi)) collapsed to T=2 for ALL annulus bounds on ISOLET/CIFAR/GIST
  (distinct T = 1.0; histogram all-2), because learned-code Hamming distances far exceed the
  binomial model at small angles (measured mean 1.56/5 bits at 7.5 deg vs 0.21 predicted).
- Norm bands degenerate: 48-88% of reference points inside the innermost band; ring sizes
  like [1294,3,0,...] - effectively one giant cell.
- Exact-distance strata on the SAME candidate sets would reach predicted variance ratios
  0.148/0.184/0.239/0.298 - the candidate sets are not the bottleneck; the partition is.
- Amazon additionally has a coverage problem (mass recall 0.865).

## Stage A (c in {5,8,12,16} x T in {default, calibrated 0.8-quantile}), 8 configs
Ranking by mean validation MARE across the four datasets:
cal0.8 dominates at c>=8 (c12 0.1960 best; default T at c16 collapses mass recall to 0.30-0.65
on GIST/ISOLET). Calibrated T preserves mass recall 1.000 everywhere.

## Stage B (single-dimension variations around L12_c12_cal0.8), 11 configs
min_collisions b in {3,4,6}: b=6 best overall (avg MARE 0.1917, recovery 0.159, beats
uniform 4/4 datasets).
t_quantile in {0.5,0.9}: both worse than 0.8 (0.1959 / 0.2007 vs 0.1960 at b=2).
layers J in {2,4}: worse (coarser rings lose the little separation available).
delta_scale 0.5: second best (0.1952) but no better than b=6 and doubles layer overhead.
epochs 48: worse (0.2020-class); convergence curves (results/convergence_v1) show flat
validation probes beyond ~epoch 24 on GIST and only a slow drift on ISOLET -> keep 24.
tables L=24: worse (0.2015) and slower.

## Frozen shared configuration (all four datasets, no per-dataset tuning)
tables=12, bits(c)=12, epochs=24, delta_scale=1.0, J=8, min_collisions=6,
T(r)=empirical monotone calibration, 0.8 quantile, equal-count angle bins fit on
TRAIN queries x reference pairs only (seed 20260915).

## Implementation changes kept separate from method-level changes
- posting/vector hybrid retrieval replaces the per-radius full np.isin scan; candidate
  semantics verified identical on 4 datasets x 50 configurations (test_fast_partition.py).
- stage timing breakdown added (encoding/hash lookup/sphere/grouping/allocation/kernel).
- Method-level: calibrated T(r) schedule (allowed single monotone empirical calibration),
  c 5->12, b 2->6 chosen on validation only.
