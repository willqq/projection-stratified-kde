# Validation-stage B1 activation and protocol clarification

Recorded before any projection configuration is evaluated. No new test or audit outcome has been read.

The initial fixed-C variance/random gate did not trigger B1: equal-occupancy B0 groups were better than random on several datasets. A subsequent score-attribution diagnostic showed why that gate alone did not answer whether the existing codes carried enough information. In CIFAR, calibrated angles had only two distinct values, with median largest ties of 98.44% for Hamming and 99.78% for real codes. Both versions were weaker than the simple norm-only grouping. On ISOLET, median distance rank correlations were 0.2105 and 0.0358, and Hamming's incremental variance reduction over norm-only was about 1.2%.

The complete M=128 validation screen then gave median Recovery about 0.077 for proportional B0+A and 0.042 for its pilot-Neyman variant. The principal full-target gains were on Amazon. These are validation findings, not a claim about the final audit.

Based on this information diagnosis, the author's permitted B1 route is activated. This is a recorded amendment to the narrower initial gate, not a claim that the initial numerical gate passed. Parameter selection remains open only on validation. The candidate budget is not expanded: the two reserved B1 slots use one fixed 64-dimensional Gaussian projection with seed 20260916, J=8, H=floor(M/4), and proportional versus robust Neyman allocation.

The projection uses training-mean centering only for numerical stability. It scans all reference projections, so C=P and the outside-C stratum is empty. This avoids carrying an ineffective MECH retrieval component into the backup. It is explicitly O(n*64) auxiliary work, with 64 full-dimensional query projection products. Kernel values and truth remain in the unchanged original feature coordinates.

The same projection and H also supply a mandatory matched single-remainder control. In total the study evaluates 11 candidate method configurations, plus matched controls whose score source follows the candidate being tested. These controls are not additional tunable algorithms or opportunities to pick a favorable subset. Every control is retained and labeled in the search record.

If projection supplies the final improvement, the manuscript must identify it as an auxiliary projection method and revise its title and mechanism description. No benefit will be attributed to the old norm–angle hash index when that index is absent from the final online path.
