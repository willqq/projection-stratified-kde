# Prospective sprint protocol

Frozen before new validation outcomes, 2026-09-16 Beijing time. This implements the author's sprint GOAL; it supersedes the previous prohibition on estimator changes.

## Inputs and held-out evidence

The estimand, original transformed feature coordinates, reference sets, h, R and old split IDs remain unchanged. The manuscript baseline is the verified c=5/L=12/b=2/J=8 model from the previous final delivery. The new branch starts at the current server commit 296379cb and imports the previously verified occupied-posting implementation from c2629750. Later c=12 results and uncommitted B0 drafts are recorded as separate historical work, without replacing the manuscript's controlled baseline or repeating their searches.

Audit IDs are randomly selected with seed 20260916 from row identifiers outside every recorded original split before new validation. There are 200 per non-Amazon dataset. Amazon has zero eligible rows. No audit evaluation occurs before the method/source freeze. The old test is explicitly an exposed comparison set; it is not described as wholly unseen.

All experimental execution uses the remote CPU environment with eight threads. Formal timing starts with the same already-transformed query boundary as the prior table. Raw feature transformation is reported separately. No training runs concurrently with formal timing. Kernel truth and exact-distance diagnostics remain outside online estimators.

## Candidate budget and selection

No more than 12 complete method configurations will be evaluated on validation. Existing baselines and matched-H controls are comparison protocols, not opportunities to expand the search. The initial screen uses all 80 validation queries, five sampling seeds and M=128. At most three finalists are extended to M=64/256. Reuse identical completed configurations. No test-based changes are permitted after freeze.

The reserved candidate slots are:

1. B0 Hamming quantile strata, J=4, candidate-only proportional estimator.
2. B0 Hamming quantile strata, J=8, candidate-only proportional estimator.
3. B0 real-code quantile strata, J=4, candidate-only proportional estimator.
4. B0 real-code quantile strata, J=8, candidate-only proportional estimator.
5. A with old annuli plus residual, H empty, proportional allocation.
6. A with old annuli plus residual, H of size floor(M/4), proportional allocation.
7. Best B0 grouping plus full residual, H empty, proportional allocation.
8. Best B0 grouping plus full residual, H of size floor(M/4), proportional allocation.
9. Configuration 8 with robust two-stage Neyman allocation.
10. Conditional B1: one fixed 64-dimensional Gaussian projection, J=8 quantile strata, full residual, H of size floor(M/4), proportional allocation.
11. Configuration 10 with robust two-stage Neyman allocation.
12. Reserved matched-H single-uniform-remainder implementation using the selected score; it can establish estimator-component gains, but is recognized as a known DEANN-style construction and cannot establish a new multilayer contribution by itself.

B1 is activated only if fixed-C diagnostics show that the available MECH scores remain weak on at least two datasets: approximate/random variance ratio above 0.95 at M=128. This gate is saved before B1 evaluation. The single projection and seed are not tuned. Unused slots are not replaced with an unbounded search.

B0's score and J are selected by median validation Recovery across the four datasets at M=128; absolute score ties within 0.02 prefer lower complete latency. These choices define the subsequent A/B0+A slots. For final selection, first maximize the number of datasets with Recovery at least 0.50 at both tested adjacent budgets. Then prefer the median Recovery across the three budgets. Differences within 0.02 favor the simpler estimator with lower geometric-mean relative latency. A complex component is retained only when its matched control demonstrates an aggregate error improvement exceeding 2% relative and improves at least two datasets without worsening another by more than 5% relative; otherwise retain the simpler parent. All failures and constraint decisions are reported.

Recovery is (E_MC-E_method)/(E_MC-E_exact_annular), without clipping. Denominators must be positive and larger than 1e-8 and 1% of E_MC; otherwise report N/A. The final report also checks query-bootstrap uncertainty of denominators. These are interpretation guards rather than targets for changing the kernel.

## Budget and correctness

H is chosen with an auxiliary score, never with a full original-space distance scan. Every exact H, pilot and final kernel evaluation counts toward the same M. H, candidate remainder cells and the outside-C residual are mutually exclusive and cover P for full-target methods. The residual uses an explicit ID complement with its O(n) identifier work counted, avoiding unbounded rejection sampling. Low-dimensional candidate scans are recorded as such, not described as sublinear.

Proportional allocation is the first reliable full-target estimator. Neyman uses at most two pilot samples per cell, a fixed shrinkage rule, minimum one main sample for each nonempty unobserved cell, and capacity limits. The pilot's exact contribution is added once; only the unobserved remainder is expanded with N'_j/b_j. If pilot/main minima do not fit, fallback is decided before any pilot kernel value is observed. The estimator is checked on enumerable finite populations and edge cases before validation screening.

## Final comparisons and attribution

Formal curves retain Exact sum, Uniform MC, Exact annular, official DEANN and the final method, with M=32/64/128/256/512, sampling seeds 0–4 and every original test query. The three independent audit sets use the same settings after freeze. Official DEANN retains its validation-selected settings, sampler and FAISS backend.

Table 2A fixes C and proportional allocation and compares the final score grouping against new same-size random and exact-distance-ordered partitions. Table 2B fixes the same retrieval, H and actual total kernel budget and compares one uniform remainder, multiple proportional strata, and robust two-stage Neyman. Exact-distance sorting is offline diagnostic only. Matched controls are assessed on the same query rows and seeds; query clusters are the unit of 1,000 bootstrap resamples.

Every online step is timed. Separate counters record kernel calls, full-dimensional distances/dot products, auxiliary scoring, posting visits and residual-ID processing. All points enter error–latency and actual-work comparisons. No unfavorable data are removed.

## Manuscript and decision

Freeze method, source hashes, calibrations, models, query IDs and seeds before formal test/audit. Update the existing manuscript locally after results; preserve a LaTeX diff. The original two figures retain their overall design with labels and flow updated to the actual algorithm. No additional main figure is introduced.

The result card separately reports EXPERIMENT_READY, CLAIM_SUPPORTED and FORMAT_READY. Missing authors/ORCIDs and unperformed author verification remain submission blockers. No upload or push is performed.
