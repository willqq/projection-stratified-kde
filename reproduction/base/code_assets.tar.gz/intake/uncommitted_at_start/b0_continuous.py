"""B0: continuous multi-table Hamming-score stratification (validation gate).

Replaces the hard nested Hamming-ball differences inside candidate C with
strata assigned by a continuous aggregate score
    s(p,q) = (1/L) * sum_l D_H(g_l(p), g_l(q)) / c
mapped to an angle estimate (linear binomial inverse or isotonic fit on TRAIN
pairs) and combined with exact stored norms into an approximate distance
    d_hat^2 = |p|^2 + |q|^2 - 2|p||q| cos(theta_hat).
Strata variant A cuts d_hat at the existing r_i boundaries (J radial cells +
one C-tail cell); variant B sorts by d_hat and reuses current ring population
sizes (diagnostic of recoverable ordering). Candidate retrieval, estimator,
allocation and sampling are unchanged. No test query is read here.
"""
from __future__ import annotations
import json
import math
import sys
import time
import numpy as np
import pandas as pd
from sklearn.isotonic import IsotonicRegression
import core as c
import run as r
import calib
import final_run

CFG = json.loads((r.JOBROOT / 'final_config.json').read_text())
BUDGETS = [64, 128, 256]
GATE_QUERIES = 24
RANDOM_PARTITIONS = 5


def per_table_hamming(index, q_codes, ids):
    out = np.empty((len(ids), index.tables_count), dtype=np.int16)
    for t in range(index.tables_count):
        out[:, t] = calib._popcount(index.point_codes[t][ids] ^ np.uint64(int(q_codes[t])))
    return out


def aggregate_score(index, q_codes, ids):
    return per_table_hamming(index, q_codes, ids).mean(axis=1) / index.bits


def fit_isotonic(index, arrays, seed=20260915, max_pairs=6144):
    rng = np.random.default_rng(seed)
    qi = rng.integers(0, len(arrays['train']), size=max_pairs)
    ri = rng.integers(0, len(arrays['reference']), size=max_pairs)
    q32 = np.ascontiguousarray(arrays['train'][qi], dtype=np.float32)
    r32 = arrays['reference'][ri]
    qn = np.linalg.norm(q32, axis=1).astype(np.float64)
    rn = np.linalg.norm(r32, axis=1).astype(np.float64)
    ok = qn * rn > 1e-12
    q32, r32, qn, rn = q32[ok], r32[ok], qn[ok], rn[ok]
    cosang = np.clip((q32.astype(np.float64) * r32.astype(np.float64)).sum(1) / (qn * rn), -1, 1)
    angles = np.arccos(cosang)
    q_codes = calib.batch_query_codes(index, q32)
    dh = np.empty((len(q32), index.tables_count), dtype=np.int16)
    for t in range(index.tables_count):
        dh[:, t] = calib._popcount(index.point_codes[t][ri] ^ q_codes[t])
    s = dh.mean(axis=1) / index.bits
    iso = IsotonicRegression(out_of_bounds='clip')
    iso.fit(s, angles)
    return iso


def dhat_from_score(s, norms_p, q_norm, mapping):
    theta = np.pi * s if mapping == 'linear' else mapping.predict(s)
    theta = np.clip(theta, 0.0, math.pi)
    d2 = norms_p ** 2 + q_norm ** 2 - 2.0 * norms_p * q_norm * np.cos(theta)
    return np.sqrt(np.maximum(d2, 0.0))


def strata_by_boundaries(ids, d_hat, radius, J):
    cuts = np.linspace(0.0, radius, J + 1)[1:] ** 2
    labels = np.searchsorted(cuts, d_hat ** 2, side='left')
    return [ids[labels == i] for i in range(J + 1)]


def gate(name):
    arrays, split, meta, ev, ev_base, assets = final_run.build(name, CFG)
    J, R = ev.layers, ev.radius
    iso = fit_isotonic(ev.index, arrays)
    rows = []
    for qi, q in enumerate(arrays['validation'][:GATE_QUERIES]):
        q32 = np.asarray(q, dtype=np.float32)
        codes = ev.index.query_codes(q32)
        union, _, rings = ev.partition(q, codes, R)
        C = np.asarray(sorted(union), dtype=np.int64)
        if not len(C):
            continue
        d2 = c.sqdist(ev.points, q)
        logk = -d2 / (2 * ev.h * ev.h)
        shift = float(logk.max())
        values = np.exp(logk - shift)
        q_norm = float(np.linalg.norm(q32))
        s = aggregate_score(ev.index, codes, C)
        ring_sizes = [len(x) for x in rings]
        boundaries = np.cumsum(ring_sizes)[:-1]
        ordered_true = C[np.argsort(logk[C], kind='stable')[::-1]]
        cases = {}
        cases['current'] = [np.asarray(sorted(x), dtype=np.int64) for x in rings]
        for mapping, tag in (('linear', 'sA_lin'), (iso, 'sA_iso')):
            d_hat = dhat_from_score(s, ev.norms[C], q_norm, mapping)
            cases[tag] = strata_by_boundaries(C, d_hat, R, J)
        d_iso = dhat_from_score(s, ev.norms[C], q_norm, iso)
        order_hat = C[np.argsort(d_iso, kind='stable')]
        cases['sB_iso'] = [x for x in np.split(order_hat, boundaries) if len(x)]
        cases['exact_on_C'] = [x for x in strata_by_boundaries(
            C, np.sqrt(np.maximum(d2[C], 0)), R, J) if len(x)]
        cases['ordered'] = [x for x in np.split(ordered_true, boundaries) if len(x)]
        cases['uniform_C'] = [C]
        cases = {k: [x for x in v if len(x)] for k, v in cases.items()}
        for budget in BUDGETS:
            base = None
            for label, cells in cases.items():
                sizes = [len(x) for x in cells]
                if sum(sizes) == 0:
                    continue
                alloc = c.allocate(sizes, budget)
                pred = c.predicted_variance([values[x] for x in cells], alloc, ev.n)
                if label == 'uniform_C':
                    base = pred
                rows.append(dict(dataset=name, query=qi, budget=budget, grouping=label,
                                 pred=pred, n_cells=len(cells),
                                 sizes=sizes[:20]))
            # random partitions at the sA_iso sizes (the proposed grouping)
            sizes = [len(x) for x in cases['sA_iso']]
            b2 = np.cumsum(sizes)[:-1]
            for ps in range(RANDOM_PARTITIONS):
                shuffled = np.random.default_rng(510000 + qi * 100 + ps).permutation(C)
                cells = [x for x in np.split(shuffled, b2) if len(x)]
                alloc = c.allocate([len(x) for x in cells], budget)
                pred = c.predicted_variance([values[x] for x in cells], alloc, ev.n)
                rows.append(dict(dataset=name, query=qi, budget=budget,
                                 grouping='random', pred=pred,
                                 n_cells=len(cells), sizes=[len(x) for x in cells][:20]))
        if (qi + 1) % 8 == 0:
            print(json.dumps({'event': 'b0_progress', 'dataset': name, 'q': qi + 1}), flush=True)
    df = pd.DataFrame(rows)
    piv = df[df.grouping == 'uniform_C'].set_index(['query', 'budget']).pred
    df['ratio'] = df.apply(
        lambda row: row.pred / piv.loc[(row.query, row.budget)]
        if (row.query, row.budget) in piv.index else np.nan, axis=1)
    summary = df.groupby('grouping')['ratio'].median()
    out = r.JOBROOT / 'results' / 'b0_gate'
    out.mkdir(parents=True, exist_ok=True)
    df.to_csv(out / f'{name}_gate_rows.csv', index=False)
    print(json.dumps({'event': 'gate_summary', 'dataset': name,
                      'median_ratios': {k: round(v, 4) for k, v in summary.items()}}), flush=True)
    return summary


if __name__ == '__main__':
    for name in sys.argv[1:] or ['isolet', 'cifar10_gist512']:
        gate(name)
