"""B0 validation selection, then sequential A1/A2 validation if needed.

Discipline: training/validation queries only; grids are exactly those named
in the sprint protocol. Selection rule fixed in advance: shared configuration
by mean rank of validation mean relative error (budgets 64/128/256) across
datasets, tie-broken by median latency; A1/A2 components are kept only when
they improve the mean validation MARE on at least half the datasets without
worsening any by more than 2% relative.
"""
from __future__ import annotations
import json
import sys
import time
import numpy as np
import pandas as pd
import core as c
import run as r
import calib
import final_run
import b0_final
import b0_continuous

CFG = json.loads((r.JOBROOT / 'final_config.json').read_text())
DATASETS = ['isolet', 'cifar10', 'cifar10_gist512', 'amazon']
BUDGETS = [64, 128, 256]
SEEDS = [0, 1, 2, 3, 4]


def build_ev(name, J, mapping, a1_tau=None, a2_frac=None, cache={}):
    if name not in cache:
        cache[name] = final_run.build(name, CFG)
    arrays, split, meta, ev_frozen, ev_base, assets = cache[name]
    iso = b0_continuous.fit_isotonic(ev_frozen.index, arrays)
    ev = b0_final.ContinuousEvaluator(
        ev_frozen.points, meta['bandwidth'], meta['radius'], J, ev_frozen.index,
        meta['delta'] * CFG['delta_scale'], CFG['min_collisions'],
        t_lookup=ev_frozen.t_lookup, mapping=mapping, iso=iso,
        a1_tau=a1_tau, a2_frac=a2_frac)
    return arrays, ev, ev_base, ev_frozen


def eval_mare(name, J, mapping, a1_tau=None, a2_frac=None, cache={}, truths_cache={}):
    arrays, ev, ev_base, ev_frozen = build_ev(name, J, mapping, a1_tau, a2_frac, cache)
    if name not in truths_cache:
        truths_cache[name] = [c.exact_log_mean(ev.points, q, ev.h) for q in arrays['validation']]
    truths = truths_cache[name]
    rows = []
    for qi, q in enumerate(arrays['validation']):
        for budget in BUDGETS:
            for seed in SEEDS:
                rng = np.random.default_rng(seed + qi * 100003)
                res = ev.evaluate('approx_annular_mech', q, budget, rng)
                err = c.errors(res['log_estimate'], truths[qi])
                rows.append(dict(budget=budget, rel=err['relative_error'],
                                 ms=res['time_ns'] / 1e6,
                                 n_cells=res['nonempty_layers'],
                                 inner=res['layer_sizes'][0] if res['layer_sizes'] else 0,
                                 iex=res.get('inner_exact_count', 0),
                                 res=res.get('residual_count', 0)))
    df = pd.DataFrame(rows)
    g = df.groupby('budget')
    return {int(b): float(g.get_group(b).rel.mean()) for b in BUDGETS}, \
           {int(b): float(g.get_group(b).ms.median()) for b in BUDGETS}, \
           {'innermost_mean': float(df.inner.mean()), 'exact_inner_rate': float((df.iex > 0).mean())}


def stage_b0():
    out = {}
    baselines = pd.read_csv(r.JOBROOT / 'results' / 'search_v1' / 'validation_baselines.csv')
    for name in DATASETS:
        # correctness: same candidate set as the frozen outer filter
        arrays, ev, ev_base, ev_frozen = build_ev(name, 8, 'iso')
        q = arrays['validation'][0]
        q32 = np.asarray(q, dtype=np.float32)
        codes = ev.index.query_codes(q32)
        C_new, _, cells = ev.partition(q, codes, ev.radius)
        C_old, _, _ = ev_frozen.partition(q, codes, ev.radius)
        assert C_new == C_old, f'{name}: candidate semantics changed!'
        # unbiasedness for f_C at large budget
        d2 = c.sqdist(ev.points, q)
        logk = -d2 / (2 * ev.h * ev.h)
        fc = float(np.log(np.exp(logk[list(C_new)]).sum() / ev.n))
        rng = np.random.default_rng(0)
        est = ev.evaluate('approx_annular_mech', q, 1600, rng)
        rel = abs(float(np.exp(est['log_estimate'] - fc)) - 1)
        print(json.dumps({'event': 'correctness', 'dataset': name,
                          'cand_equal': True, 'fC_rel_gap_largebudget': round(rel, 5),
                          'cells': [len(x) for x in cells]}), flush=True)
        uni = baselines[(baselines.dataset == name) & (baselines.method == 'uniform_mc')].set_index('budget').mare
        exa = baselines[(baselines.dataset == name) & (baselines.method == 'exact_annular')].set_index('budget').mare
        for J in (4, 8, 12, 16):
            for mapping in ('iso', 'linear'):
                mares, mss, diag = eval_mare(name, J, mapping)
                rec = {b: (uni[b] - mares[b]) / (uni[b] - exa[b]) for b in BUDGETS}
                key = f'{name}_J{J}_{mapping}'
                out[key] = dict(mares=mares, ms=mss, recovery=rec, **diag)
                print(json.dumps({'event': 'b0_cfg', 'dataset': name, 'J': J,
                                  'mapping': mapping, 'mare': {k: round(v, 4) for k, v in mares.items()},
                                  'ms': {k: round(v, 2) for k, v in mss.items()},
                                  'recovery': {k: round(v, 3) for k, v in rec.items()},
                                  'inner_mean': round(diag['innermost_mean'], 1)}), flush=True)
    return out


def stage_a(b0_best):
    """Sequential A1 (tau) then A2 (residual fraction) validation.

    Keep rule declared in advance: a component value is kept only if it
    improves the mean validation MARE on at least half the datasets and
    worsens none by more than 2% relative; among kept values the lowest mean
    MARE across datasets wins.
    """
    J, mapping = b0_best['J'], b0_best['mapping']
    baselines = pd.read_csv(r.JOBROOT / 'results' / 'search_v1' / 'validation_baselines.csv')
    uni = {n: baselines[(baselines.dataset == n) & (baselines.method == 'uniform_mc')].set_index('budget').mare for n in DATASETS}
    exa = {n: baselines[(baselines.dataset == n) & (baselines.method == 'exact_annular')].set_index('budget').mare for n in DATASETS}

    def run_grid(fixed, dim, values):
        table = {}
        for val in values:
            cfgv = dict(fixed)
            cfgv[dim] = val
            per = {}
            for name in DATASETS:
                mares, mss, diag = eval_mare(name, J, mapping, cfgv['a1_tau'], cfgv['a2_frac'])
                rec = {b: (uni[name][b] - mares[b]) / (exa[name][b] - mares[b]) for b in BUDGETS}
                per[name] = dict(mares=mares, ms=mss, recovery=rec, **diag)
                print(json.dumps({'event': dim, 'dataset': name, str(dim): val,
                                  'mare': {k: round(x, 4) for k, x in mares.items()},
                                  'recovery': {k: round(x, 3) for k, x in rec.items()},
                                  'ms': {k: round(x, 2) for k, x in mss.items()},
                                  'iex_rate': round(diag['exact_inner_rate'], 2)}), flush=True)
            table[val] = per
        return table

    def choose(table, base_val, fixed, dim):
        base_mean = {n: float(np.mean(list(table[base_val][n]['mares'].values()))) for n in DATASETS}
        best, best_score = base_val, float(np.mean(list(base_mean.values())))
        for val, per in table.items():
            if val == base_val:
                continue
            means = {n: float(np.mean(list(per[n]['mares'].values()))) for n in DATASETS}
            improved = sum(means[n] < base_mean[n] for n in DATASETS)
            worsened = any(means[n] > base_mean[n] * 1.02 for n in DATASETS)
            score = float(np.mean(list(means.values())))
            if improved >= 2 and not worsened and score < best_score:
                best, best_score = val, score
        return best, best_score

    fixed = {'a1_tau': None, 'a2_frac': None}
    a1_table = run_grid(fixed, 'a1_tau', [None, 0.25, 0.5])
    a1_best, a1_score = choose(a1_table, None, fixed, 'a1_tau')
    print(json.dumps({'event': 'a1_choice', 'a1_tau': a1_best, 'mean_mare': a1_score}), flush=True)
    fixed['a1_tau'] = a1_best
    a2_table = run_grid(fixed, 'a2_frac', [None, 0.1, 0.25])
    a2_best, a2_score = choose(a2_table, None, fixed, 'a2_frac')
    print(json.dumps({'event': 'a2_choice', 'a2_frac': a2_best, 'mean_mare': a2_score}), flush=True)
    return {'a1_table': a1_table, 'a1_best': a1_best, 'a2_table': a2_table, 'a2_best': a2_best}


if __name__ == '__main__':
    which = sys.argv[1] if len(sys.argv) > 1 else 'b0'
    if which == 'b0':
        out = stage_b0()
        (r.JOBROOT / 'results' / 'b0_validation.json').write_text(json.dumps(out, indent=2))
    else:
        b0_best = json.loads((r.JOBROOT / 'results' / 'b0_best.json').read_text())
        out = stage_a(b0_best)
        (r.JOBROOT / 'results' / 'a_validation.json').write_text(json.dumps(out, indent=2))
