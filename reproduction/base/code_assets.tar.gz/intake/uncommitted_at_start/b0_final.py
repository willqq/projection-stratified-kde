"""Final sprint evaluator: continuous-score stratification (B0) with optional
A1 exact innermost stratum and A2 residual stratum (route A add-ons).

Candidate retrieval is unchanged (sphere band + one calibrated outer hash
pass). Inside C, strata come from the aggregate Hamming score mapped through
a train-fitted isotonic calibration (or the linear binomial inverse control)
and combined with exact norms into d_hat, cut at the J radial boundaries plus
one C-tail cell. Estimator, allocation and log-weighted aggregation follow the
existing framework; A1 evaluates the innermost cell exactly when its
population is at most tau*M, A2 adds a uniform residual stratum on P\\C with
rejection membership tests. All costs are timed.
"""
from __future__ import annotations
import math
import time
import numpy as np
import core as c
import calib
import fast_core
import fast_partition as fp
import mech_annulus_experiments as source


def aggregate_scores(index, q_codes, ids):
    dh = np.empty((len(ids), index.tables_count), dtype=np.int16)
    for t in range(index.tables_count):
        dh[:, t] = calib._popcount(index.point_codes[t][ids] ^ np.uint64(int(q_codes[t])))
    return dh.mean(axis=1) / index.bits


class ContinuousEvaluator(fast_core.FastEvaluator):
    """layers here = J for the approximate strata only; baselines keep J=8."""

    def __init__(self, points, h, radius, layers=8, index=None, delta=None,
                 min_collisions=2, t_lookup=None, mapping='iso', iso=None,
                 a1_tau=None, a2_frac=None):
        super().__init__(points, h, radius, layers, index, delta, min_collisions, t_lookup)
        self.mapping_kind = mapping
        self.iso = iso
        self.a1_tau = a1_tau
        self.a2_frac = a2_frac

    def score_to_angle(self, s):
        if self.mapping_kind == 'linear':
            return np.pi * s
        return np.clip(self.iso.predict(s), 0.0, math.pi)

    def partition(self, q, codes, radius, stages=None, counters=None):
        if stages is None:
            stages = {}
        for key in ('hash_lookup_ns', 'hit_count_ns', 'sphere_ns', 'score_ns', 'strata_ns', 'grouping_ns'):
            stages.setdefault(key, 0)
        if counters is None:
            counters = {}
        q32 = np.asarray(q, dtype=np.float32)
        q_norm = float(np.linalg.norm(q32))
        J = self.layers
        # --- candidate C: identical semantics to the frozen outer filter ---
        t0 = time.perf_counter_ns()
        bounds_outer = np.asarray([radius])
        if self.t_lookup is not None:
            T_outer = calib.calibrated_hamming_radii(q_norm, bounds_outer, self.t_lookup)
        else:
            T_outer = fp.default_hamming_radii(self.index, q_norm, bounds_outer)
        passed = fp.posting_hash_ids(self.index, codes, int(T_outer[0]),
                                     self.min_collisions, stages, counters)
        low, high = source.sphere_layer_bounds(q_norm, radius, self.delta)
        rows = [self.sphere_table[layer] for layer in range(low, high + 1) if layer in self.sphere_table]
        band = np.unique(np.concatenate(rows)) if rows else np.zeros(0, dtype=np.int32)
        keep = np.isin(band, passed, assume_unique=False)
        C = band[keep]
        zero_ids = getattr(self.index, 'zero_norm_ids', None)
        if zero_ids is None:
            zero_ids = set(np.flatnonzero(self.norms == 0).tolist())
        if len(C) and zero_ids:
            C = C[~np.isin(C, np.asarray(sorted(zero_ids), dtype=np.int64))]
        if q_norm <= radius and zero_ids:
            C = np.union1d(C, np.asarray(sorted(zero_ids), dtype=np.int64))
        stages['sphere_ns'] += time.perf_counter_ns() - t0
        # --- continuous score, calibration, d_hat, strata ---
        t1 = time.perf_counter_ns()
        s = aggregate_scores(self.index, codes, C) if len(C) else np.zeros(0)
        stages['score_ns'] += time.perf_counter_ns() - t1
        t2 = time.perf_counter_ns()
        if len(C):
            theta = self.score_to_angle(s)
            d2h = self.norms[C] ** 2 + q_norm ** 2 - 2.0 * self.norms[C] * q_norm * np.cos(theta)
            d_hat = np.sqrt(np.maximum(d2h, 0.0))
            cuts = np.linspace(0.0, radius, J + 1)[1:] ** 2
            labels = np.searchsorted(cuts, d_hat ** 2, side='left')
            cells = [np.sort(C[labels == i]) for i in range(J + 1)]
            cells = [x for x in cells if len(x)]
        else:
            cells = []
        stages['strata_ns'] += time.perf_counter_ns() - t2
        stages['candidate_ns'] = (stages['hash_lookup_ns'] + stages['sphere_ns'] +
                                  stages['score_ns'] + stages['strata_ns'])
        stats = {'raw_hash_size': float(len(passed)),
                 'outer_prefilter_size': float(len(band)),
                 'outer_hash_size': float(len(C)),
                 'inner_prefilter_size': 0.0, 'inner_hash_size': 0.0,
                 'ring_count': float(len(cells)),
                 'mean_ring_size': float(np.mean([len(x) for x in cells])) if cells else 0.0,
                 'max_ring_size': float(max([len(x) for x in cells])) if cells else 0.0}
        return set(C.tolist()), stats, cells

    def evaluate(self, method, q, budget, rng):
        if method != 'approx_annular_mech':
            return super().evaluate(method, q, budget, rng)
        start = time.perf_counter_ns()
        stages = {k: 0 for k in ('encoding_ns', 'radius_ns', 'candidate_ns',
                                 'hash_lookup_ns', 'hit_count_ns', 'sphere_ns',
                                 'score_ns', 'strata_ns', 'grouping_ns',
                                 'allocation_ns', 'kernel_ns')}
        counters = {'distance_evaluations': 0, 'kernel_evaluations': 0,
                    'hash_id_checks': 0, 'code_distance_checks': 0,
                    'posting_visits': 0}
        q32 = np.asarray(q, dtype=np.float32)
        t = time.perf_counter_ns()
        codes = self.index.query_codes(q32)
        stages['encoding_ns'] = time.perf_counter_ns() - t
        _, _, cells = self.partition(q, codes, self.radius, stages, counters)
        n = self.n
        inner_exact_ids = np.zeros(0, dtype=np.int64)
        sampling_cells = list(cells)
        exact_budget_used = 0
        # A1: evaluate the innermost cell exactly when small enough.
        if self.a1_tau is not None and sampling_cells:
            n1 = len(sampling_cells[0])
            if n1 <= self.a1_tau * budget:
                inner_exact_ids = sampling_cells.pop(0)
                exact_budget_used = n1
        remaining_budget = max(budget - exact_budget_used, 0)
        # A2: residual stratum on P \ C via rejection membership tests.
        residual_ids = np.zeros(0, dtype=np.int64)
        if self.a2_frac is not None and self.a2_frac > 0 and cells:
            cand = np.sort(np.concatenate([np.concatenate(cells).astype(np.int64)])) if cells else np.zeros(0, dtype=np.int64)
            residual_budget = int(round(self.a2_frac * budget))
            residual_budget = min(residual_budget, n - len(cand) - len(inner_exact_ids))
            if residual_budget > 0:
                accepted = []
                proposals = 0
                guard = 0
                need_scale = n / max(n - len(cand), 1)
                while sum(len(a) for a in accepted) < residual_budget and guard < 200:
                    need = residual_budget - sum(len(a) for a in accepted)
                    draw = rng.integers(0, n, size=int(need * need_scale * 1.2) + 8)
                    proposals += len(draw)
                    fresh = draw[~np.isin(draw, cand, assume_unique=False)]
                    if len(fresh):
                        accepted.append(np.unique(fresh))
                    guard += 1
                residual_ids = (np.concatenate(accepted) if accepted
                                else np.zeros(0, dtype=np.int64))[:residual_budget]
                counters['residual_proposals'] = proposals
                counters['residual_samples'] = len(residual_ids)
        # Allocation over sampling cells.
        t3 = time.perf_counter_ns()
        if sampling_cells and remaining_budget > 0:
            merged = list(sampling_cells)
            while len(merged) > remaining_budget:
                merged[:2] = [np.concatenate(merged[:2])]
            counts = c.allocate([len(x) for x in merged], remaining_budget)
            ids, logw = c.sample_ids(merged, counts, rng)
        else:
            ids, logw = np.zeros(0, dtype=np.int64), np.zeros(0)
            counts = []
        all_ids, all_logw = [], []
        if len(inner_exact_ids):
            all_ids.append(inner_exact_ids)
            all_logw.append(np.zeros(len(inner_exact_ids)))
        if len(ids):
            all_ids.append(ids)
            all_logw.append(logw)
        if len(residual_ids):
            n0 = n - sum(len(x) for x in cells) - len(inner_exact_ids)
            all_ids.append(residual_ids)
            all_logw.append(np.full(len(residual_ids), math.log(n0 / len(residual_ids))))
        stages['allocation_ns'] = time.perf_counter_ns() - t3
        t4 = time.perf_counter_ns()
        if not all_ids:
            value = -math.inf
            eval_count = 0
        else:
            eval_ids = np.concatenate(all_ids)
            logw_all = np.concatenate(all_logw)
            d2 = c.sqdist(self.points[eval_ids], q)
            value = c.log_weighted_estimate(-d2 / (2 * self.h * self.h), logw_all, n)
            eval_count = len(eval_ids)
            counters['kernel_evaluations'] = eval_count
            counters['distance_evaluations'] = eval_count
        stages['kernel_ns'] = time.perf_counter_ns() - t4
        total = time.perf_counter_ns() - start
        return dict(log_estimate=value, time_ns=total,
                    actual_samples=eval_count,
                    candidate_size=sum(len(x) for x in cells),
                    nonempty_layers=len(cells),
                    layer_sizes=[len(x) for x in cells],
                    allocation=list(counts),
                    inner_exact_count=int(len(inner_exact_ids)),
                    residual_count=int(len(residual_ids)),
                    **stages, **counters)
