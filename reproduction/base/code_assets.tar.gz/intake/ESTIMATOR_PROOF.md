# Full-target estimator: definition, conditional argument and implementation contract

This module implements a known stratified/full-residual sampling construction. Exact retrieved contributions plus uniform remainder sampling are not claimed as new. Any proposed contribution must be established by the parent's matched-H, matched-budget grouping and allocation controls.

## Population and interface

For a fixed query, let `y_p = exp(log_kernel(p))` denote its original-feature-space Gaussian contribution and let `f = sum(y_p)/n`. The caller supplies a deterministic exact subset H and disjoint cells D_j covering P minus H. Candidate-external residual points must appear as a cell. Scores and any partition fitting must be frozen before final evaluation; no full-dimensional exact query/reference distances may be used for selection unless their cost and evaluations are counted.

```
estimate_strata(n, H, cells, budget, rng, kernel_fn,
                allocation='proportional', pilot_max=2,
                shrinkage=0.5, validate=False)
```

`kernel_fn(ids)` returns original-space log contributions only for those IDs. The implementation performs exactly `min(n, budget)` distinct evaluations when the supplied H leaves enough budget to estimate the unobserved population. It rejects H exceeding the budget, or H consuming the entire budget when unobserved points remain. It has no query/reference matrix, target cache or database access.

By default, only total supplied cardinality is checked. `validate=True` additionally checks identifier range and complete disjoint coverage using a full identifier scan. It is for correctness tests or explicitly timed validation; it must not be silently included/excluded from online cost. The caller remains responsible for maintaining the partition invariant online.

## Fixed proportional allocation

Empty cells are removed. Every nonempty cell receives one main sample. The remaining capped budget is apportioned in proportion to the residual cell capacities, with deterministic capacity clipping and largest-remainder ties broken by input cell order. Samples are uniform without replacement within each cell.

The estimate is

`f_hat = [sum_H y + sum_j (N_j/m_j) sum_{F_j} y]/n`.

Given H and cells, the mean of each sample sum is `(m_j/N_j) sum_{D_j} y`. Therefore `E[f_hat | H, cells] = f`.

## Two-stage robust allocation

For each cell the provisional pilot count is `a_j = min(2, N_j)`. Before any pilot kernel is observed, check that all pilot counts plus one main sample in every nonempty unobserved remainder fit within the remaining budget. If they do not fit, fall back to the fixed proportional rule. If there are more cells than remaining sample slots, consecutive cells are deterministically merged into that many groups, before sampling or observation. If the full population fits the budget, take a census in one kernel batch.

For an admissible two-stage run, draw each pilot P_j uniformly without replacement. Let `U_j = D_j minus P_j`, `N'_j = N_j-a_j`. Compute sample variance `s_j^2` from each pilot (zero if fewer than two values). Let `s_pool^2` be the sample variance of the pooled pilots across cells. The fixed shrinkage rule is

`sigma_tilde_j = sqrt(0.5*s_j^2 + 0.5*s_pool^2)`.

For numerical stability, all pilot kernel values are first divided by their common maximum finite contribution. This common factor cancels in the allocation weights. Each nonempty U_j receives one main sample, and the remaining main budget follows weights `N'_j*sigma_tilde_j`, with deterministic capacity clipping and largest-remainder allocation. If every active weight is zero, the remaining budget follows remaining capacities. Thus zero estimated variance never suppresses the mandatory observation of a nonempty remainder.

After counts b_j are fixed, draw F_j uniformly without replacement in U_j. Pilot IDs are excluded by an exact bijection from compressed complement positions, avoiding a per-cell full-size boolean mask. The estimate is

`f_hat = {sum_H y + sum_j [sum_{P_j} y + (N'_j/b_j) sum_{F_j} y]}/n`,

with the last term omitted when N'_j=0.

Condition on the fixed query/reference set, H, the cells, and the complete pilot outcomes. The chosen counts b_j are then fixed. Uniform sampling in U_j gives

`E[(N'_j/b_j) sum_{F_j} y | pilots] = sum_{U_j} y`.

Consequently the conditional mean equals the exact full-population target, including both observed pilot contributions and every unobserved remainder:

`E[f_hat | pilots, H, cells] = [sum_H y + sum_j sum_{D_j} y]/n = f`.

The variance conditional on pilots and counts is

`Var(f_hat | pilots) = n^-2 sum_j N'^2_j (1-b_j/N'_j) S'^2_j/b_j`,

where S'^2_j is the finite-population sample variance in U_j, and census/singleton terms have zero variance. The law of total variance has no additional variance-of-conditional-mean term because that conditional mean is exactly f. This argument does not claim the pilot-driven allocation improves efficiency; the matched proportional comparison must establish that empirically.

Pilot and main samples are never mixed into a conventional sample mean with their adaptive total count. Each pilot contribution is counted once with coefficient one; each main contribution receives its appropriate unobserved-population weight.

## Returned fields and timing boundary

- `log_estimate`: log of the full-population estimate; aggregation is in log space.
- `actual_samples`, `selected_ids`, `selected_log_kernel_values`: auditable evaluated identifiers and values.
- `H_count`, `cell_sizes`, `input_cell_sizes`, `pilot_counts`, `main_counts`, `pilot_ids`, `main_ids`: allocation evidence.
- `effective_allocation`, `fallback`, `merged_cells`: explicit census, proportional fallback or adjacent-cell merging records.
- `scaled_shrunk_sigma`: standard deviations on the common scaled pilot-value scale.
- `kernel_calls`, `kernel_call_sizes`: one proportional/census kernel batch or at most two Neyman batches.
- `sampling_ns`, `allocation_ns`, `kernel_ns`, `aggregation_ns`: mutually exclusive measured phases.
- `total_ns`, `unassigned_ns`: function entry to final result construction, and remaining Python/bookkeeping overhead.

Parent-level query transformation, scoring, retrieval, sorting, construction of H/cells and residual IDs are outside this function and must be included in the complete-query timer. No performance claim can be drawn from the estimator timer alone.

## Correctness evidence

Remote test command:

```
OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 MKL_NUM_THREADS=8 NUMEXPR_NUM_THREADS=8 CUDA_VISIBLE_DEVICES= \
/root/autodl-tmp/icassp_revision_20260915/.venv/bin/python \
/root/autodl-tmp/icassp_sprint_20260916_0103/worktree/mech_annulus_project_clean/revision/test_sprint_estimator.py \
--out /root/autodl-tmp/icassp_sprint_20260916_0103/results/estimator_checks
```

`conditional_expectation.csv` enumerates 300 complete pilot conditions and every possible formal uniform sample combination in each condition, giving 2,700 main outcomes across heterogeneous, single-spike and constant populations. Both adaptive allocation patterns (1,2) and (2,1) occur in the heterogeneous case. The largest conditional mean difference from full truth is 1.1102230246251565e-16. This is a complete finite-population conditional check, not a Monte Carlo approximation.

Additional passing checks include 18 enumerated proportional outcomes, 574 complement-bijection cases, 7,700 allocation-capacity/budget cases, 240 seeded edge-case executions, invalid coverage rejection, and all-zero kernels. Edge cases cover empty C via a single residual layer, C=P, singleton cells/H, budget at or above n, M=32, pre-observation pilot fallback, deterministic cell merging, and log contributions at -1000 where ordinary exponentiation would underflow.

All raw records and environment/source hash are in `results/estimator_checks/`. No training, validation, test or audit data were read by these tests.
